from Sea import Sea

# main program
if __name__ == "__main__":
    river = Sea()
    print("Initial Details:")
    river.printDetails()

    river.setName("Amazon")
    river.setArea(7000)
    river.setType("River")

    river.depthChange(10)
    river.absorbWater(50)
    river.evaporate(20)

    river.pollute()

    print("\nModified Details:")
    river.printDetails()
    print("\nNew Mods:")
    river.dirtyWater()
    # river.clearWater()
