#class WaterBody
class WaterBody:
    def __init__(self):
        self.__name = "Nile"
        self.__area = 6650
        self.__type = "River"
        self.__isPolluted = False
        self.__depth = 0
    def setName(self,name):
        self.__name = name
    def setArea(self,area):
        self.__area = area
    def setType(self,type):
        self.__type = type
    def getName(self):
        print("Accessed name: " + str(self.__name))
        return self.__name
    def getArea(self):
        print("Accessed area: " + str(self.__area))
        return self.__area
    def getType(self):
        print("Acessed type: " + str(self.__type))
        return self.__type
    def increaseArea(self,additionalArea):
        self.__area += additionalArea
        print("Increased area by " + str(additionalArea) + "to " + str(self.__area))
    def changeType(self,newType):
        self.__type = newType
        print("Changed type to " + str(newType))
    def printDetails(self):
        print("Name: " + str(self.__name))
        print("Area: " + str(self.__area))
        print("Type: " + str(self.__type))
        print("Polluted: " + str(self.__isPolluted))
        print("Depth: " + str(self.__depth))
    def rainfallEffect(self,rainfall):
        if rainfall>50:
            self.increaseArea(rainfall)
        else:
            print("Rainfall was not sufficient to increase area")
    def pollute(self):
        self.__isPolluted = True
        print("Water body is now polluted")
    def clean(self):
        self.__isPolluted = False
        print("Water body is now clean")
    def setDepth(self,depth):
        self.__depth = depth
        print("Set depth to " + str(depth))
    def depthChange(self,change):
        self.__depth += change
        print("Changed depth by " + str(change) + " to " + str(self.__depth))
    def evaporate(self, amount):
        if amount<self.__depth:
            self.__depth -= amount
            print("Evaporated " + str(amount) + " of water")
        else:
            self.__depth = 0
            print("Evaporated all water, depth is now 0")
    def absorbWater(self,amount):
        self.__depth += amount
        print("Absorbed " + str(amount) + " of water")
    def dirtyWater(self):
        self.__isPolluted = True
        print("Water is now polluted.")
    def clearWater(self):
        self.__isPolluted = False
        print("Water is now clear.")