from WaterBody import WaterBody

#class Sea
class Sea(WaterBody):
    def __init__(self):
        super().__init__()

